ALTER SYSTEM SET ob_vector_memory_limit_percentage = 30;
