# Dify

- copied from https://github.com/langgenius/dify
- removed `container_name`
- removed `ports`
