# Twenty

- copied from https://github.com/twentyhq/twenty
- removed `ports`
