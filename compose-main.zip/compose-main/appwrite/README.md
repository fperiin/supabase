# Appwrite

- copied from https://github.com/appwrite/appwrite
  - https://appwrite.io/install/compose
  - https://appwrite.io/install/env
- removed `ports`
- removed `container_name`
