# Supabase

- copied from https://github.com/supabase/supabase/tree/master/docker
- removed `container_name`
- removed `ports`
